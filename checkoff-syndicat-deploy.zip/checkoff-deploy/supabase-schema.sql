-- À exécuter une seule fois dans Supabase : Project > SQL Editor > New query > Run

create extension if not exists "pgcrypto";

create table checkoff_submissions (
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  prenom text not null,
  matricule text not null,
  service text not null,
  employeur text,
  email text,
  telephone text,
  signature text not null,
  date_signature timestamptz not null default now()
);

alter table checkoff_submissions enable row level security;

-- Autorise les membres (clé publique "anon") à enregistrer leur accord
create policy "membres_peuvent_enregistrer"
  on checkoff_submissions for insert
  to anon
  with check (true);

-- Autorise la lecture depuis l'application (onglet Responsables, protégé par code d'accès côté application)
create policy "lecture_pour_application"
  on checkoff_submissions for select
  to anon
  using (true);
