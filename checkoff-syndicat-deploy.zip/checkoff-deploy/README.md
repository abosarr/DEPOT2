# Accord de Check-off — déploiement

Ce dossier contient l'application complète, prête à déployer. Deux étapes : créer la base de données (Supabase, gratuit), puis déployer le site (Vercel, gratuit). Comptez 10 à 15 minutes, aucune compétence technique requise au-delà de copier-coller.

## 1. Créer la base de données (Supabase)

1. Aller sur https://supabase.com et créer un compte gratuit.
2. Cliquer **New project**, lui donner un nom (ex. `checkoff-syndicat`), choisir un mot de passe de base de données (à conserver de côté), valider.
3. Une fois le projet créé, aller dans **SQL Editor** (menu de gauche) > **New query**.
4. Ouvrir le fichier `supabase-schema.sql` fourni dans ce dossier, copier tout son contenu, le coller dans l'éditeur, cliquer **Run**.
5. Aller dans **Project Settings** (roue crantée) > **API**. Noter deux valeurs :
   - **Project URL** (ressemble à `https://xxxxx.supabase.co`)
   - **anon public key** (une longue chaîne de caractères)

## 2. Déployer le site (Vercel)

1. Aller sur https://vercel.com et créer un compte gratuit (possible avec un compte GitHub, Google, ou un e-mail).
2. Créer un compte GitHub si vous n'en avez pas (https://github.com), créer un nouveau dépôt (repository), et y déposer tous les fichiers de ce dossier (bouton **Add file > Upload files** sur GitHub, glisser-déposer tout le contenu).
3. Dans Vercel, cliquer **Add New > Project**, choisir **Import** sur le dépôt GitHub créé à l'étape précédente.
4. Avant de cliquer sur Déployer, ouvrir la section **Environment Variables** et ajouter :
   - `VITE_SUPABASE_URL` → coller la Project URL notée à l'étape 1
   - `VITE_SUPABASE_ANON_KEY` → coller la anon public key notée à l'étape 1
5. Cliquer **Deploy**. Après une à deux minutes, Vercel affiche le lien du site, du type :
   `https://checkoff-syndicat.vercel.app`

C'est ce lien qu'il faut transmettre aux membres du syndicat.

## 3. Avant de diffuser le lien

- Ouvrir `src/App.jsx`, chercher la ligne `const ACCESS_CODE = "RESPONSABLES2026";` et la remplacer par un code choisi avec le bureau syndical, puis redéployer (Vercel redéploie automatiquement à chaque mise à jour du dépôt GitHub).
- Relire le mémo `memo-installation-checkoff.docx` fourni séparément — notamment le point sur les limites de sécurité de l'espace « Responsables ».
- Envisager de relier un nom de domaine propre au syndicat dans **Vercel > Settings > Domains** si vous en possédez un.

## Développement local (optionnel)

Pour tester sur son propre ordinateur avant de déployer :

```
npm install
cp .env.example .env
# renseigner les deux valeurs Supabase dans .env
npm run dev
```
