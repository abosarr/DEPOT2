import React, { useState, useEffect, useMemo } from "react";
import { Stamp, Users, Search, Download, ChevronRight, Lock } from "lucide-react";
import { supabase } from "./supabaseClient";

// ---- Design tokens ----
// Ink:      #1B2A44 (deep union-ledger navy)
// Paper:    #ECE6D6 (aged ledger paper, warmer/greyer than the AI-default cream)
// Brick:    #A83C2E (stamp red — deliberately not the terracotta #D97757 default)
// Brass:    #9C7A2E (seal/brass accent)
// Steel:    #3E5C76 (secondary ink)
// Charcoal: #232420 (body text)

const ACCESS_CODE = "RESPONSABLES2026";

function refFromId(id) {
  return "CO-" + id.slice(-6).toUpperCase();
}

function Seal({ size = 84 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-hidden="true">
      <circle cx="50" cy="50" r="46" fill="none" stroke="#9C7A2E" strokeWidth="2" />
      <circle cx="50" cy="50" r="38" fill="none" stroke="#9C7A2E" strokeWidth="1" strokeDasharray="2 3" />
      <text x="50" y="46" textAnchor="middle" fontFamily="'IBM Plex Mono', monospace" fontSize="9" fill="#9C7A2E" letterSpacing="1">
        ACCORD
      </text>
      <text x="50" y="60" textAnchor="middle" fontFamily="'IBM Plex Mono', monospace" fontSize="9" fill="#9C7A2E" letterSpacing="1">
        CHECK-OFF
      </text>
    </svg>
  );
}

function Field({ label, required, children, hint }) {
  return (
    <label className="block mb-5">
      <span className="block text-[11px] tracking-[0.14em] uppercase font-medium mb-1.5" style={{ color: "#3E5C76", fontFamily: "'IBM Plex Mono', monospace" }}>
        {label}{required && <span style={{ color: "#A83C2E" }}> *</span>}
      </span>
      {children}
      {hint && <span className="block text-xs mt-1" style={{ color: "#6b6b63" }}>{hint}</span>}
    </label>
  );
}

const inputStyle = {
  fontFamily: "'Source Serif 4', Georgia, serif",
  background: "#F5F1E6",
  border: "1.5px solid #C9C0A6",
  color: "#232420",
};

function MemberForm({ onSubmitted }) {
  const [form, setForm] = useState({
    nom: "", prenom: "", matricule: "", service: "", employeur: "",
    email: "", telephone: "", accepte: false, signature: "",
  });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const set = (k) => (e) => {
    const v = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [k]: v }));
  };

  const valid = form.nom && form.prenom && form.matricule && form.service &&
    form.accepte && form.signature.trim().length > 1 &&
    form.signature.trim().toLowerCase() === `${form.prenom} ${form.nom}`.trim().toLowerCase();

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!form.accepte) { setError("Vous devez cocher la case d'accord pour continuer."); return; }
    if (form.signature.trim().toLowerCase() !== `${form.prenom} ${form.nom}`.trim().toLowerCase()) {
      setError("La signature doit correspondre exactement à votre prénom et nom saisis ci-dessus.");
      return;
    }
    setSubmitting(true);
    try {
      const { data, error: dbError } = await supabase
        .from("checkoff_submissions")
        .insert({
          nom: form.nom, prenom: form.prenom, matricule: form.matricule,
          service: form.service, employeur: form.employeur,
          email: form.email, telephone: form.telephone, signature: form.signature,
        })
        .select()
        .single();
      if (dbError) throw dbError;
      onSubmitted({
        id: data.id, ...form, dateSignature: data.date_signature,
      });
    } catch (err) {
      setError("Une erreur est survenue lors de l'enregistrement. Merci de réessayer.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-xl mx-auto">
      <div className="grid grid-cols-2 gap-x-4">
        <Field label="Prénom" required>
          <input style={inputStyle} className="w-full px-3 py-2.5 text-[15px] outline-none focus:border-[#3E5C76]" value={form.prenom} onChange={set("prenom")} />
        </Field>
        <Field label="Nom" required>
          <input style={inputStyle} className="w-full px-3 py-2.5 text-[15px] outline-none focus:border-[#3E5C76]" value={form.nom} onChange={set("nom")} />
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-x-4">
        <Field label="Matricule / N° employé" required>
          <input style={inputStyle} className="w-full px-3 py-2.5 text-[15px] outline-none focus:border-[#3E5C76]" value={form.matricule} onChange={set("matricule")} />
        </Field>
        <Field label="Service / Département" required>
          <input style={inputStyle} className="w-full px-3 py-2.5 text-[15px] outline-none focus:border-[#3E5C76]" value={form.service} onChange={set("service")} />
        </Field>
      </div>
      <Field label="Employeur" hint="Nom de l'entreprise ou de l'administration">
        <input style={inputStyle} className="w-full px-3 py-2.5 text-[15px] outline-none focus:border-[#3E5C76]" value={form.employeur} onChange={set("employeur")} />
      </Field>
      <div className="grid grid-cols-2 gap-x-4">
        <Field label="Téléphone">
          <input style={inputStyle} className="w-full px-3 py-2.5 text-[15px] outline-none focus:border-[#3E5C76]" value={form.telephone} onChange={set("telephone")} />
        </Field>
        <Field label="E-mail">
          <input type="email" style={inputStyle} className="w-full px-3 py-2.5 text-[15px] outline-none focus:border-[#3E5C76]" value={form.email} onChange={set("email")} />
        </Field>
      </div>

      <div className="mt-6 mb-5 p-4" style={{ background: "#E4DCC5", borderLeft: "3px solid #A83C2E" }}>
        <p className="text-[14px] leading-relaxed" style={{ fontFamily: "'Source Serif 4', Georgia, serif", color: "#232420" }}>
          En cochant cette case, je confirme mon accord pour que mon employeur procède au
          prélèvement à la source (« check-off ») de mes cotisations syndicales sur mon salaire,
          au bénéfice du syndicat, conformément à la réglementation en vigueur et jusqu'à retrait
          écrit de ma part.
        </p>
        <label className="flex items-start gap-2.5 mt-3 cursor-pointer select-none">
          <input type="checkbox" checked={form.accepte} onChange={set("accepte")} className="mt-1 w-4 h-4 accent-[#A83C2E]" />
          <span className="text-[14px] font-medium" style={{ color: "#232420" }}>Je donne mon accord au check-off syndical</span>
        </label>
      </div>

      <Field label="Signature (tapez votre prénom et nom)" required hint="Doit correspondre exactement au prénom et nom saisis plus haut">
        <input style={inputStyle} className="w-full px-3 py-2.5 text-[15px] italic outline-none focus:border-[#3E5C76]" placeholder="Prénom Nom" value={form.signature} onChange={set("signature")} />
      </Field>

      {error && <p className="text-sm mb-3" style={{ color: "#A83C2E" }}>{error}</p>}

      <button
        type="submit"
        disabled={submitting}
        className="w-full py-3.5 mt-2 flex items-center justify-center gap-2 text-[15px] tracking-wide font-medium transition-opacity disabled:opacity-50"
        style={{ background: "#1B2A44", color: "#ECE6D6", fontFamily: "'IBM Plex Mono', monospace" }}
      >
        {submitting ? "ENREGISTREMENT..." : "CONFIRMER MON ACCORD"} <ChevronRight size={16} />
      </button>
    </form>
  );
}

function Receipt({ entry, onReset }) {
  const ref = refFromId(entry.id);
  const d = new Date(entry.dateSignature);
  return (
    <div className="max-w-xl mx-auto text-center py-4">
      <div className="mx-auto mb-2 flex justify-center"><Seal /></div>
      <h3 className="text-2xl mb-1" style={{ fontFamily: "'Fraunces', Georgia, serif", color: "#1B2A44" }}>Accord enregistré</h3>
      <p className="text-sm mb-6" style={{ color: "#3E5C76" }}>Merci, {entry.prenom} {entry.nom}. Votre confirmation a bien été transmise aux responsables du syndicat.</p>

      <div className="relative mx-auto" style={{ maxWidth: 420 }}>
        <div className="p-6 text-left" style={{ background: "#F5F1E6", border: "1.5px solid #C9C0A6" }}>
          <div className="flex justify-between items-baseline mb-4 pb-3" style={{ borderBottom: "1px dashed #C9C0A6" }}>
            <span className="text-xs tracking-widest uppercase" style={{ fontFamily: "'IBM Plex Mono', monospace", color: "#3E5C76" }}>Référence</span>
            <span className="text-lg" style={{ fontFamily: "'IBM Plex Mono', monospace", color: "#A83C2E" }}>{ref}</span>
          </div>
          <dl className="text-sm space-y-2" style={{ fontFamily: "'Source Serif 4', Georgia, serif", color: "#232420" }}>
            <div className="flex justify-between"><dt style={{ color: "#6b6b63" }}>Matricule</dt><dd>{entry.matricule}</dd></div>
            <div className="flex justify-between"><dt style={{ color: "#6b6b63" }}>Service</dt><dd>{entry.service}</dd></div>
            <div className="flex justify-between"><dt style={{ color: "#6b6b63" }}>Date</dt><dd>{d.toLocaleDateString("fr-FR")} {d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</dd></div>
          </dl>
        </div>
      </div>

      <button onClick={onReset} className="mt-8 text-sm underline underline-offset-4" style={{ color: "#3E5C76" }}>
        Enregistrer un autre membre sur cet appareil
      </button>
    </div>
  );
}

function AdminGate({ onUnlock }) {
  const [code, setCode] = useState("");
  const [err, setErr] = useState(false);
  return (
    <div className="max-w-xs mx-auto text-center py-10">
      <Lock size={22} style={{ color: "#3E5C76" }} className="mx-auto mb-3" />
      <p className="text-sm mb-4" style={{ color: "#3E5C76" }}>Espace réservé aux responsables du syndicat</p>
      <input
        type="password"
        value={code}
        onChange={(e) => { setCode(e.target.value); setErr(false); }}
        placeholder="Code d'accès"
        style={inputStyle}
        className="w-full px-3 py-2.5 text-center text-[15px] outline-none mb-3"
      />
      {err && <p className="text-xs mb-2" style={{ color: "#A83C2E" }}>Code incorrect.</p>}
      <button
        onClick={() => (code === ACCESS_CODE ? onUnlock() : setErr(true))}
        className="w-full py-2.5 text-[13px] tracking-wide font-medium"
        style={{ background: "#1B2A44", color: "#ECE6D6", fontFamily: "'IBM Plex Mono', monospace" }}
      >
        ACCÉDER
      </button>
    </div>
  );
}

function AdminTable() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  async function load() {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("checkoff_submissions")
        .select("*")
        .order("date_signature", { ascending: false });
      if (error) throw error;
      setRows(
        (data || []).map((r) => ({
          id: r.id, nom: r.nom, prenom: r.prenom, matricule: r.matricule,
          service: r.service, employeur: r.employeur, email: r.email,
          telephone: r.telephone, dateSignature: r.date_signature,
        }))
      );
    } catch (e) { setRows([]); }
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter((r) => `${r.nom} ${r.prenom} ${r.matricule} ${r.service}`.toLowerCase().includes(s));
  }, [rows, q]);

  function exportCsv() {
    const headers = ["Reference", "Prenom", "Nom", "Matricule", "Service", "Employeur", "Telephone", "Email", "Date signature"];
    const lines = [headers.join(";")].concat(
      filtered.map((r) => [refFromId(r.id), r.prenom, r.nom, r.matricule, r.service, r.employeur, r.telephone, r.email, new Date(r.dateSignature).toLocaleString("fr-FR")]
        .map((v) => `"${(v || "").toString().replace(/"/g, '""')}"`).join(";"))
    );
    const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "accords-checkoff.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-1 min-w-[200px]" style={{ background: "#F5F1E6", border: "1.5px solid #C9C0A6" }}>
          <Search size={15} style={{ color: "#6b6b63", marginLeft: 10 }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher un membre..." className="flex-1 px-2 py-2 text-sm outline-none bg-transparent" style={{ color: "#232420" }} />
        </div>
        <button onClick={exportCsv} className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium" style={{ background: "#1B2A44", color: "#ECE6D6", fontFamily: "'IBM Plex Mono', monospace" }}>
          <Download size={13} /> EXPORTER CSV
        </button>
        <button onClick={load} className="px-3 py-2 text-xs" style={{ color: "#3E5C76", border: "1px solid #C9C0A6" }}>Actualiser</button>
      </div>

      <p className="text-xs mb-3" style={{ color: "#6b6b63", fontFamily: "'IBM Plex Mono', monospace" }}>
        {loading ? "Chargement..." : `${filtered.length} accord(s) enregistré(s)`}
      </p>

      <div className="overflow-x-auto" style={{ border: "1.5px solid #C9C0A6" }}>
        <table className="w-full text-sm" style={{ fontFamily: "'Source Serif 4', Georgia, serif" }}>
          <thead>
            <tr style={{ background: "#1B2A44", color: "#ECE6D6" }}>
              {["Réf.", "Membre", "Matricule", "Service", "Contact", "Date"].map((h) => (
                <th key={h} className="text-left px-3 py-2 text-[11px] tracking-wider uppercase font-medium" style={{ fontFamily: "'IBM Plex Mono', monospace" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, i) => (
              <tr key={r.id} style={{ background: i % 2 ? "#F5F1E6" : "#ECE6D6", borderTop: "1px solid #D8D0B8" }}>
                <td className="px-3 py-2" style={{ fontFamily: "'IBM Plex Mono', monospace", color: "#A83C2E" }}>{refFromId(r.id)}</td>
                <td className="px-3 py-2">{r.prenom} {r.nom}</td>
                <td className="px-3 py-2">{r.matricule}</td>
                <td className="px-3 py-2">{r.service}</td>
                <td className="px-3 py-2 text-xs">{r.telephone}{r.telephone && r.email ? " · " : ""}{r.email}</td>
                <td className="px-3 py-2 text-xs">{new Date(r.dateSignature).toLocaleDateString("fr-FR")}</td>
              </tr>
            ))}
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={6} className="px-3 py-8 text-center text-sm" style={{ color: "#6b6b63" }}>Aucun accord enregistré pour le moment.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState("form");
  const [unlocked, setUnlocked] = useState(false);
  const [receipt, setReceipt] = useState(null);

  return (
    <div className="min-h-screen w-full" style={{ background: "#ECE6D6", fontFamily: "'Source Serif 4', Georgia, serif" }}>
      <header style={{ background: "#1B2A44" }} className="px-5 py-5">
        <div className="max-w-xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Stamp size={22} style={{ color: "#9C7A2E" }} />
            <div>
              <h1 className="text-lg leading-tight" style={{ fontFamily: "'Fraunces', Georgia, serif", color: "#ECE6D6" }}>Accord de Check-off</h1>
              <p className="text-[11px] tracking-[0.14em] uppercase" style={{ color: "#8fa3bd", fontFamily: "'IBM Plex Mono', monospace" }}>Confirmation des membres</p>
            </div>
          </div>
          <div className="flex text-[11px]" style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
            <button onClick={() => { setView("form"); }} className="px-3 py-1.5" style={{ color: view === "form" ? "#ECE6D6" : "#8fa3bd", borderBottom: view === "form" ? "2px solid #9C7A2E" : "2px solid transparent" }}>MEMBRE</button>
            <button onClick={() => setView("admin")} className="px-3 py-1.5 flex items-center gap-1" style={{ color: view === "admin" ? "#ECE6D6" : "#8fa3bd", borderBottom: view === "admin" ? "2px solid #9C7A2E" : "2px solid transparent" }}><Users size={12} /> RESPONSABLES</button>
          </div>
        </div>
      </header>

      <main className="px-5 py-10">
        {view === "form" && (
          receipt ? <Receipt entry={receipt} onReset={() => setReceipt(null)} /> : <MemberForm onSubmitted={setReceipt} />
        )}
        {view === "admin" && (
          <div className="max-w-4xl mx-auto">
            {!unlocked ? <AdminGate onUnlock={() => setUnlocked(true)} /> : <AdminTable />}
          </div>
        )}
      </main>

      <footer className="text-center pb-8">
        <p className="text-[11px]" style={{ color: "#9a9382", fontFamily: "'IBM Plex Mono', monospace" }}>Les données saisies sont transmises aux responsables du syndicat</p>
      </footer>
    </div>
  );
}
